Q1: What is Matplotlib? Why is it used? Name five plots that can be plotted using the Pyplot module of
Matplotlib.
Q2: What is a scatter plot? Use the following code to generate data for x and y. Using this generated data
plot a scatter plot.
import numpy as np
np.random.seed(3)
x = 3 + np.random.normal(0, 2, 50)
y = 3 + np.random.normal(0, 2, len(x))
Note: Also add title, xlabel, and ylabel to the plot.
Q3: Why is the subplot() function used? Draw four line plots using the subplot() function.
Use the following data:
import numpy as np
For line 1: x = np.array([0, 1, 2, 3, 4, 5]) and y = np.array([0, 100, 200, 300, 400, 500])
For line 2: x = np.array([0, 1, 2, 3, 4, 5]) and y = np.array([50, 20, 40, 20, 60, 70])
For line 3: x = np.array([0, 1, 2, 3, 4, 5]) and y = np.array([10, 20, 30, 40, 50, 60])
For line 4: x = np.array([0, 1, 2, 3, 4, 5]) and y = np.array([200, 350, 250, 550, 450, 150])
Q4: What is a bar plot? Why is it used? Using the following data plot a bar plot and a horizontal bar plot.
import numpy as np
company = np.array(["Apple", "Microsoft", "Google", "AMD"])
profit = np.array([3000, 8000, 1000, 10000])
Q5: What is a box plot? Why is it used? Using the following data plot a box plot.
box1 = np.random.normal(100, 10, 200)
box2 = np.random.normal(90, 20, 200)

## Ans 1
Matplotlib is a powerful data visualization library for Python that allows users to create a wide range of plots, charts, and graphs to represent their data in a clear and concise way. Matplotlib is widely used in scientific computing, data analysis, and data visualization tasks.

Matplotlib's key strength is its ability to create publication-quality plots with a high degree of customization. It provides an extensive set of functions that allow users to create a variety of plots, including line plots, scatter plots, bar plots, histograms, pie charts, and many more.

Some common plots that can be plotted using the Pyplot module of Matplotlib are:

Line plot: This plot is used to represent the relationship between two variables on a continuous scale, typically using a line to connect the data points.

Scatter plot: This plot is used to represent the relationship between two variables on a continuous scale, typically using a set of points to represent the data.

Bar plot: This plot is used to represent the comparison of data across different categories, typically using rectangular bars with heights or lengths proportional to the values they represent.

Histogram: This plot is used to represent the distribution of a single variable, typically using a series of rectangles with heights proportional to the frequency of values within each interval.

Pie chart: This plot is used to represent the proportion of data in different categories, typically using a circular chart divided into segments proportional to the values they represent

## Ans 2
Scatter plots are the graphs that present the relationship between two variables in a data-set. It represents data points on a two-dimensional plane or on a Cartesian system. The independent variable or attribute is plotted on the X-axis, while the dependent variable is plotted on the Y-axis.



```python
import matplotlib.pyplot as plt
import numpy as np
np.random.seed(3)
x = 3 + np.random.normal(0, 2, 50)
y = 3 + np.random.normal(0, 2, len(x))
plt.scatter(x,y)
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title("x vs y")
```




    Text(0.5, 1.0, 'x vs y')




    
![png](output_3_1.png)
    


## Ans 3 
The subplot() function is used to create multiple plots on a single figure. It allows users to arrange multiple subplots in a grid format and specify the number of rows, columns, and the position of each subplot.


```python
import numpy as np
x1 = np.array([0, 1, 2, 3, 4, 5]) 
y1 = np.array([0, 100, 200, 300, 400, 500])

x2 = np.array([0, 1, 2, 3, 4, 5]) 
y2 = np.array([50, 20, 40, 20, 60, 70])

x3 = np.array([0, 1, 2, 3, 4, 5]) 
y3 = np.array([10, 20, 30, 40, 50, 60])

x4 = np.array([0, 1, 2, 3, 4, 5])
y4 = np.array([200, 350, 250, 550, 450, 150])
fig, axs = plt.subplots(2, 2, figsize=(8, 8))

# Plot line 1 on the first subplot
axs[0, 0].plot(x1, y1)
axs[0, 0].set_title('Line 1')

# Plot line 2 on the second subplot
axs[0, 1].plot(x2, y2)
axs[0, 1].set_title('Line 2')

# Plot line 3 on the third subplot
axs[1, 0].plot(x3, y3)
axs[1, 0].set_title('Line 3')

# Plot line 4 on the fourth subplot
axs[1, 1].plot(x4, y4)
axs[1, 1].set_title('Line 4')

# Add a title to the entire figure
fig.suptitle('Four Line Plots')
```




    Text(0.5, 0.98, 'Four Line Plots')




    
![png](output_5_1.png)
    


## Ans 4 
Bar plots are a type of data visualization used to represent data in the form of rectangular bars. The height of each bar represents the value of a data point, and the width of each bar represents the category of the data.


```python
import numpy as np
company = np.array(["Apple", "Microsoft", "Google", "AMD"])
profit = np.array([3000, 8000, 1000, 10000])
plt.figure(figsize=(5,3))
plt.bar(company,profit,color = '#7E10D5')
plt.xlabel("Company")
plt.ylabel("Profit")
plt.title("This is my bar plot")
                  
```




    Text(0.5, 1.0, 'This is my bar plot')




    
![png](output_7_1.png)
    



```python
import numpy as np
company = np.array(["Apple", "Microsoft", "Google", "AMD"])
profit = np.array([3000, 8000, 1000, 10000])
plt.figure(figsize=(5,3))
plt.barh(company,profit,color = '#7E10D5')
plt.xlabel("Company")
plt.ylabel("Profit")
plt.title("This is my horizontal bar plot")
```




    Text(0.5, 1.0, 'This is my horizontal bar plot')




    
![png](output_8_1.png)
    


## Ans 5 
A Box Plot is also known as Whisker plot is created to display the summary of the set of data values having properties like minimum, first quartile, median, third quartile and maximum. In the box plot, a box is created from the first quartile to the third quartile, a vertical line is also there which goes through the box at the median. Here x-axis denotes the data to be plotted while the y-axis shows the frequency distribution


```python
box1 = np.random.normal(100, 10, 200)
box2 = np.random.normal(90, 20, 200)
data = (box1, box2)
fig, ax = plt.subplots()
ax.boxplot(data)
ax.set_xticklabels(["Box 1","Box 2"])
ax.set_ylabel("Value")
plt.title("This is my box plot")
```




    Text(0.5, 1.0, 'This is my box plot')




    
![png](output_10_1.png)
    



```python

```
