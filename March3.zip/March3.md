Que 1: Name any five plots that we can plot using the Seaborn library. Also, state the uses of each plot.

Que 2: Load the "fmri" dataset using the load_dataset function of seaborn. Plot a line plot using x =
"timepoint" and y = "signal" for different events and regions.
Note: timepoint, signal, event, and region are columns in the fmri dataset.

Que 3: Load the "titanic" dataset using the load_dataset function of seaborn. Plot two box plots using x =
'pclass', y = 'age' and y = 'fare'.
Note: pclass, age, and fare are columns in the titanic dataset.

Que 4: Use the "diamonds" dataset from seaborn to plot a histogram for the 'price' column. Use the hue
parameter for the 'cut' column of the diamonds dataset.

Que 5: Use the "iris" dataset from seaborn to plot a pair plot. Use the hue parameter for the "species" column
of the iris dataset.

Que 6: Use the "flights" dataset from seaborn to plot a heatmap.

## Ans 1
Seaborn library provides a wide range of plots for data visualization. Here are five popular plots and their uses:

a) Scatter plot: It shows the relationship between two variables by plotting their values in a two-dimensional coordinate system.

b) Line plot: It shows the trend of a variable over time by plotting the values of the variable against time.

c) Bar plot: It shows the comparison of a variable across different categories by plotting the values of the variable as bars.

d) Histogram: It shows the distribution of a variable by grouping the values into bins and plotting the frequency of the values in each bin as bars.

e) Box plot: It shows the distribution of a variable by plotting the quartiles of the data, with the median as a horizontal line inside the box.

## Ans 2


```python
import seaborn as sns
fmri_data = sns.load_dataset("fmri")
sns.lineplot(x="timepoint", y="signal", hue="event", style="region", data=fmri_data)
```




    <AxesSubplot: xlabel='timepoint', ylabel='signal'>




    
![png](output_3_1.png)
    


## Ans 3


```python
import seaborn as sns
titanic_data = sns.load_dataset("titanic")
sns.boxplot(x="pclass", y="age", data=titanic_data)
sns.boxplot(x="pclass", y="fare", data=titanic_data)
```




    <AxesSubplot: xlabel='pclass', ylabel='fare'>




    
![png](output_5_1.png)
    


## Ans 4


```python
import seaborn as sns
diamonds_data = sns.load_dataset("diamonds")
sns.histplot(data=diamonds_data, x="price", hue="cut")
```




    <AxesSubplot: xlabel='price', ylabel='Count'>




    
![png](output_7_1.png)
    


## Ans 5


```python
import seaborn as sns
iris_data = sns.load_dataset("iris")
sns.pairplot(data=iris_data, hue="species")
```




    <seaborn.axisgrid.PairGrid at 0x7fc3373d0cd0>




    
![png](output_9_1.png)
    


## Ans 6


```python
import seaborn as sns
flights_data = sns.load_dataset("flights")
flights_pivot = flights_data.pivot("month", "year", "passengers")
sns.heatmap(flights_pivot, cmap="coolwarm")
```

    /tmp/ipykernel_137/854984100.py:3: FutureWarning: In a future version of pandas all arguments of DataFrame.pivot will be keyword-only.
      flights_pivot = flights_data.pivot("month", "year", "passengers")





    <AxesSubplot: xlabel='year', ylabel='month'>




    
![png](output_11_2.png)
    



```python

```
